---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

> For general tech support, please see www.highcharts.com/support.
> Please report only issues about `highcharts-angular` wrapper or content of this repository.
> For general issues with Highcharts and TypeScript the correct repository to report such issues is [main Highcharts repository](https://github.com/highcharts/highcharts/issues).

### Requested feature description
A clear and concise description of what you expected to happen.
