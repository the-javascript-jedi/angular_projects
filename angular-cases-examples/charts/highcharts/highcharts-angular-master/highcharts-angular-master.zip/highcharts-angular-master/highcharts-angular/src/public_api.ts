/*
 * Public API Surface of highcharts-angular
 */

export * from './lib/highcharts-chart.module';
export * from './lib/highcharts-chart.component';
